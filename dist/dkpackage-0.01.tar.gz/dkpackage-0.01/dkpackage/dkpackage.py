def start():
    print("DKpackage: Started!")
def stop():
    print("DKpackage: Stopped!!")